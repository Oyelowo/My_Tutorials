import React, { useState, useEffect } from "react";
import ReactDOM from "react-dom";

import "./styles.css";

const randomNumWithin = (min: number, max: number) =>
  Math.floor(Math.random() * (max - min + 1) + min);

const Typer = () => {
  const [show, setShow] = useState(false);

  const toggleTyperTimer = () => setInterval(() => setShow(!show), 600);
  useEffect(
    () => {
      const timer = toggleTyperTimer();
      return () => clearInterval(timer);
    },
    [show]
  );

  return (
    <span
      style={{
        visibility: show && "hidden",
        borderRight: "2px solid #eaeaea",
        padding: "10px 7px 10px 0px"
      }}
    />
  );
};

const intro = `Hello!, I'm a software developer and data analyst.
My languages: Java, JavaScript/Typescript, Python, Ruby and R.
Other Dev tools(Libraries and Frameworks):
HTML5, CSS3, Sass, React/React Native & Redux, Mobx, Node , Express , MongoDB & Mongoose; and many more.
Testing: 
Jest, Enzyme; and cypress
My data analytics tools: 
Python, R, SPSS, Excel, ArcGIS, and QGIS.
Feel free to contact me`;

const TypeWords = () => {
  const [typeCounter, setTypeCounter] = useState(0);
  //const intro = "This boy really knows what he is doing. right?";
  const [sentence, setSentence] = useState("");
  //const toggleTyperTimer = () => setInterval(() => setShow(!show), 600);

  const updateSentence = () => {
    const updated = sentence + intro[typeCounter];
    setSentence(updated);
    setTypeCounter(typeCounter + 1);
    console.log(sentence);
  };

  const sentenceExhausted = sentence.length === intro.length;
  useEffect(
    () => {
      const timer = setInterval(
        () => !sentenceExhausted && updateSentence(),
        randomNumWithin(70, 120)
      );
      return () => clearInterval(timer);
    },
    [typeCounter, sentence]
  );

  return (
    <span
      style={{
        textShadow: "4px 4px 0px rgba(0, 0, 0, 0.1)",
        fontSize: "33px",
        fontFamily: "Oleo Script', Helvetica, sans-serif",
        fontStyle: "italic"
      }}
    >
      {sentence}
    </span>
  );
};

//font: 400 100px / 1.3 ;

const App = () => {
  const [startTyping, setStartTyping] = useState(false);

  const startTypingAt = timeInMilliSeconds =>
    setTimeout(() => setStartTyping(true), timeInMilliSeconds);

  useEffect(
    () => {
      const timer = startTypingAt(3000);
      return () => clearTimeout(timer);
    },
    [startTyping]
  );

  return (
    <div className="App">
      <h1>About Oyelowo</h1>
      {startTyping && <TypeWords />}
      <Typer />
    </div>
  );
};

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
